#############################################################################
#case 1, Size under null hypothesis##########################################
#############################################################################

rep = 100000;

theta = 0.5;
alpha = 2; beta = 2;

Narray = c(30, 60, 100, 300, 600, 900);
pkw = array(0, dim = c(3, length(Narray), rep));
pw = array(0, dim = c(3, length(Narray), rep));
sizekw = array(0, dim = c(3, 3, length(Narray)));
sizew = array(0, dim = c(3, 3, length(Narray)));
w = pw;

jj = 1; K = 2; Nprop = c(.65, 1);
for(ii in 1:2){
   Nbase = Narray[ii];
   for(kk in 1:rep){
	N = round(Nbase*Nprop);
	###########Generate Data ###################
	Q = rbinom(sum(N), 1, theta);
	X1 = rbeta(N[1], alpha, beta)
	X1 = Q[1:N[1]]*X1;
	X2 = rbeta(N[2], alpha, beta)
	X2 = Q[N[1] + 1:N[2]]*X2;

	###########Wilcoxon Rank Sum Test ############
	pkw[jj, ii, kk] = wilcox.test(X1, X2)$p.value;
	
	###########Our Test ###################
	n = c(sum(Q[1:N[1]]), sum(Q[N[1] + 1:N[2]]))
	prop = n/N; pmax = max(prop); pmean = mean(prop);
	Ntrun = round(pmax*N);
	X1trun = c(X1[Q[1:N[1]] == 1], rep(0, Ntrun[1] - n[1]));
	X2trun = c(X2[Q[N[1] + 1:N[2]] == 1], rep(0, Ntrun[2]- n[2]));
	rankdata = sum(Ntrun) + 1 - rank(c(X1trun, X2trun));
	r = sum(rankdata[1:Ntrun[1]]);
	s = r - Ntrun[1]*(sum(Ntrun) + 1)/2;

	v1 = pmean*(1 - pmean);
	var1 = N[1]*N[2]*pmean*v1*(sum(N)*pmean + 3*(1 - pmean)/2) + sum(N^2)*v1^2*5/4 + 2*sqrt(2/pi)*pmean*(sum(N)*v1)^(1.5)*sqrt(N[1]*N[2]);
	var1 = var1/4;
	var2 = N[1]*N[2]*pmean^2*(sum(N)*pmean + 1)/12;
	vars = var1 + var2;
	w[jj, ii, kk] = s/sqrt(vars);
	}
	pw[jj,ii,] = 2*(1 - pnorm(abs(w[jj,ii,])));
	print(ii)
}
pkw[jj, 3:6, ] = pkw2[jj, 1:4, ]
pw[jj, 3:6, ] = pw2[jj, 1:4, ]
w[jj, 3:6, ] = w2[jj, 1:4, ]
for(ii in 1:length(Narray)){
	sizekw[jj, 1, ii] = mean(pkw[jj, ii, ] < 0.05);
	sizew[jj, 1, ii] = mean(pw[jj, ii, ] < 0.05);
	sizekw[jj, 2, ii] = mean(pkw[jj, ii, ] < 0.01);
	sizew[jj, 2, ii] = mean(pw[jj, ii, ] < 0.01);
	sizekw[jj, 3, ii] = mean(pkw[jj, ii, ] < 0.001);
	sizew[jj, 3, ii] = mean(pw[jj, ii, ] < 0.001);
}

jj = 2; K = 3;
for(ii in 1:2){
   N  = Narray[ii];
   for(kk in 1:rep){

	###########Generate Data ###################
	Q = rbinom(3*N, 1, theta);
	X = rbeta(3*N, alpha, beta)
	X = Q*X;
	X1 = X[1:N];
	X2 = X[N + 1:N];
	X3 = X[N*2 + 1:N];

	###########Kruskal Wallis Test ############
	data = list(X1, X2, X3);
	pkw[jj, ii, kk] = kruskal.test(data)$p.value;
	
	###########Our Test ###################
	n = c(sum(Q[1:N]), sum(Q[N+1:N]), sum(Q[N*2+1:N])); nmax = max(n);
	ind = which(Q == 1);
	X1trun = c(X[ind[ind <= N]], rep(0, nmax - n[1]));
	X2trun = c(X[ind[ind > N & ind <= 2*N]], rep(0, nmax - n[2]));
	X3trun = c(X[ind[ind > 2*N]], rep(0, nmax - n[3]));
	rankdata = K*nmax + 1 - rank(c(X1trun, X2trun, X3trun));
	r = c(sum(rankdata[1:nmax]), sum(rankdata[nmax+1:nmax]), sum(rankdata[2*nmax+1:nmax]) ); 
	s = r - nmax*(K*nmax + 1)/2;
	u = c(s[1] - s[2], sum(s[1:2]) - 2*s[3]);
	thetam = mean(n)/N;
	
	simun = matrix(rbinom(5000*K, N, thetam), nrow = 5000, ncol = K);
	simunmax = apply(simun, 1, max); simusum = apply(simun, 1, sum);
	varsimu1 = numeric(K - 1); varsimu2 = varsimu1;
	varsimu1[1] = mean(simunmax^2*(simun[,1] - simun[,2])^2)*K^2/4;
	varsimu2[1] = mean((simun[,1]*simun[,2]*4 + simun[,3]*(simun[,1] + simun[,2]))*(simusum+1)/12);
	for(ss in 2:(K-1)){
		simuss = apply(simun[,1:ss], 1, sum);
		varsimu1[ss] = mean(simunmax^2*(simuss - simun[,ss+1]*ss)^2)*K^2/4;
		varsimu2[ss] = mean((simuss*simun[, ss+1]*(ss+1)^2 + (simusum - simuss - simun[,ss+1])*(simuss + ss^2*simun[,ss+1]))*(simusum+1)/12);
	}
	varsimu = varsimu1 + varsimu2;
	w[jj, ii, kk] = sum(u^2/varsimu);
	}
	pw[jj,ii,] = pchisq(w[jj,ii,], 2, lower.tail = F);
	print(ii)
}
pkw[jj, 3:6, ] = pkw2[jj, 1:4, ]
pw[jj, 3:6, ] = pw2[jj, 1:4, ]
w[jj, 3:6, ] = w2[jj, 1:4, ]
for(ii in 1:length(Narray)){
	sizekw[jj, 1, ii] = mean(pkw[jj, ii, ] < 0.05);
	sizew[jj, 1, ii] = mean(pw[jj, ii, ] < 0.05);
	sizekw[jj, 2, ii] = mean(pkw[jj, ii, ] < 0.01);
	sizew[jj, 2, ii] = mean(pw[jj, ii, ] < 0.01);
	sizekw[jj, 3, ii] = mean(pkw[jj, ii, ] < 0.001);
	sizew[jj, 3, ii] = mean(pw[jj, ii, ] < 0.001);
}


jj = 3; K = 3; Nprop = c(0.7, 1, 1.5);
for(ii in 1:2){
   Nbase = Narray[ii];
   for(kk in 1:rep){
	N = round(Nbase*Nprop);
	###########Generate Data ###################
	Q = rbinom(sum(N), 1, theta);
	X1 = rbeta(N[1], alpha, beta)
	X1 = Q[1:N[1]]*X1;
	X2 = rbeta(N[2], alpha, beta)
	X2 = Q[N[1] + 1:N[2]]*X2;
	X3 = rbeta(N[3], alpha, beta)
	X3 = Q[N[1] + N[2] +1:N[3]]*X3;

	###########Kruskal Wallis Test ############
	data = list(X1, X2, X3);
	pkw[jj, ii, kk] = kruskal.test(data)$p.value;
	
	###########Our Test ###################
	n = c(sum(Q[1:N[1]]), sum(Q[N[1] + 1:N[2]]), sum(Q[N[1] + N[2] +1:N[3]]))
	prop = n/N; pmax = max(prop);
	Ntrun = round(pmax*N);
	X1trun = c(X1[Q[1:N[1]] == 1], rep(0, Ntrun[1] - n[1]));
	X2trun = c(X2[Q[N[1] + 1:N[2]] == 1], rep(0, Ntrun[2]- n[2]));
	X3trun = c(X3[Q[N[1] + N[2] +1:N[3]] == 1], rep(0, Ntrun[3]- n[3]));
	rankdata = sum(Ntrun) + 1 - rank(c(X1trun, X2trun, X3trun));
	r = c(sum(rankdata[1:Ntrun[1]]), sum(rankdata[Ntrun[1]+1:Ntrun[2]]), sum(rankdata[sum(Ntrun[1:2])+1:Ntrun[3]]) ); 
	s = r - Ntrun*(sum(Ntrun) + 1)/2;
	u = c(N[2]*s[1] - N[1]*s[2], N[3]*sum(s[1:2]) - s[3]*sum(N[1:2]));
	u = u/Nbase^2;

	thetam = mean(prop);
	simun = matrix(0, nrow = 5000, ncol = K); simup = simun;
	for(ss in 1:K){
		simun[,ss] = rbinom(5000, N[ss], thetam);		
		simup[,ss] = simun[,ss]/N[ss];
	}
	simupmax = apply(simup, 1, max);
	varsimu = numeric(K - 1);
	varsimu[1] = Nprop[2]^2*mean(simupmax^2*(simup[,1] - simup[,2])^2)*N[1]^2;
	for(ss in 2:(K-1)){
		varsimu[ss] = Nprop[ss+1]^2*mean(simupmax^2*(apply(simun[,1:ss], 1, sum) - simup[,ss+1]*sum(N[1:ss]))^2);
	}
	varsimu = varsimu*(sum(Nprop))^2/4;

	varu2 = c(Nprop[1]*Nprop[2], Nprop[3]*sum(Nprop))*(Nprop[1] + Nprop[2])*sum(Nprop)*thetam^2*(sum(N)*thetam + 1)/12;
	varu = varsimu + varu2;
	w[jj, ii, kk] = sum(u^2/varu);
	}
	pw[jj,ii,] = pchisq(w[jj,ii,], 2, lower.tail = F);
	print(ii)
}
pkw[jj, 3:6, ] = pkw2[jj, 1:4, ]
pw[jj, 3:6, ] = pw2[jj, 1:4, ]
w[jj, 3:6, ] = w2[jj, 1:4, ]
for(ii in 1:length(Narray)){
	sizekw[jj, 1, ii] = mean(pkw[jj, ii, ] < 0.05);
	sizew[jj, 1, ii] = mean(pw[jj, ii, ] < 0.05);
	sizekw[jj, 2, ii] = mean(pkw[jj, ii, ] < 0.01);
	sizew[jj, 2, ii] = mean(pw[jj, ii, ] < 0.01);
	sizekw[jj, 3, ii] = mean(pkw[jj, ii, ] < 0.001);
	sizew[jj, 3, ii] = mean(pw[jj, ii, ] < 0.001);
}
save(w, pkw, pw, sizew, sizekw, Narray, theta, alpha, beta, rep, file = "ANOVAexp1.RData")
rm(list = ls())


#################################################################################
#case 2, unequal size tests with the same nonzero functions and different theta#
##############################################################################
rep = 1000;
K = 3;

thetamatrix = c(0.2, 0.3, 0.4); Nprop = c(1.3, 1, 0.8);
alpha = 2; beta = 2;
pkw = array(0, dim = c(4, 30, rep));
pw = array(0, dim = c(4, 30, rep));
powerkw = matrix(0, nrow = 4, ncol = 30);
powerw = matrix(0, nrow = 4, ncol = 30);
kw = pkw; w = pw;

for(ii in 1:30){
   Nbase = ii*10;
   for(jj in 1:4){
      theta = thetamatrix + 0.1*jj;
   for(kk in 1:rep){
	###########Generate Data ###################
	N = round(Nbase*Nprop);
	###########Generate Data ###################
	Q1 = rbinom(N[1], 1, theta[1]);
	X1 = rbeta(N[1], alpha, beta)
	X1 = Q1*X1;
	Q2 = rbinom(N[2], 1, theta[2]);
	X2 = rbeta(N[2], alpha, beta)
	X2 = Q2*X2;
	Q3 = rbinom(N[3], 1, theta[3]);
	X3 = rbeta(N[3], alpha, beta)
	X3 = Q3*X3;

	###########Kruskal Wallis Test ############
	data = list(X1, X2, X3);
	pkw[jj, ii, kk] = kruskal.test(data)$p.value;
	
	###########Our Test ###################
	n = c(sum(Q1), sum(Q2), sum(Q3))
	prop = n/N; pmax = max(prop);
	Ntrun = round(pmax*N);
	X1trun = c(X1[Q1 == 1], rep(0, Ntrun[1] - n[1]));
	X2trun = c(X2[Q2 == 1], rep(0, Ntrun[2]- n[2]));
	X3trun = c(X3[Q3 == 1], rep(0, Ntrun[3]- n[3]));
	rankdata = sum(Ntrun) + 1 - rank(c(X1trun, X2trun, X3trun));
	r = c(sum(rankdata[1:Ntrun[1]]), sum(rankdata[Ntrun[1]+1:Ntrun[2]]), sum(rankdata[sum(Ntrun[1:2])+1:Ntrun[3]]) ); 
	s = r - Ntrun*(sum(Ntrun) + 1)/2;
	u = c(N[2]*s[1] - N[1]*s[2], N[3]*sum(s[1:2]) - s[3]*sum(N[1:2]))/Nbase^2;

	thetam = mean(prop);
	simun = matrix(0, nrow = 5000, ncol = K); simup = simun;
	for(ss in 1:K){
		simun[,ss] = rbinom(5000, N[ss], thetam);		
		simup[,ss] = simun[,ss]/N[ss];
	}
	simupmax = apply(simup, 1, max);
	varsimu = numeric(K - 1);
	varsimu[1] = Nprop[2]^2*mean(simupmax^2*(simup[,1] - simup[,2])^2)*N[1]^2;
	for(ss in 2:(K-1)){
		varsimu[ss] = Nprop[ss+1]^2*mean(simupmax^2*(apply(simun[,1:ss], 1, sum) - simup[,ss+1]*sum(N[1:ss]))^2);
	}
	varsimu = varsimu*(sum(Nprop))^2/4;

	varu2 = c(Nprop[1]*Nprop[2], Nprop[3]*sum(Nprop))*(Nprop[1] + Nprop[2])*sum(Nprop)*thetam^2*(sum(N)*thetam + 1)/12;
	varu = varsimu + varu2;
	w[jj, ii, kk] = sum(u^2/varu);
	}
	pw = pchisq(w, 2, lower.tail = F);
	powerkw[jj, ii] = mean(pkw[jj, ii, ] < 0.005);
	powerw[jj, ii] = mean(pw[jj, ii, ] < 0.005);
	}
	print(ii)
}

pdf("C:/Users/wanjiew/Dropbox/Penn/exp2.pdf",width=7,height=7)
N = (1:30)*10;
par(mfrow = c(2,2))
for(jj in 1:4){
	plot(N, powerkw[jj,], type = "l", lwd = 2, lty = 2, ylim = c(0, 1), ylab = "Power")
	lines(N, powerw[jj,], lwd = 2)
}
dev.off()
save(w, pkw, pw, powerkw, powerw, alpha, beta,N, Nprop, thetamatrix, rep, file = "ANOVAexp2.RData")
rm(list = ls())



#############################################################################
#case 3, unequal size tests with the dufferent nonzero functions and different theta
#############################################################################

rep = 10000;
K = 3;

theta = c(0.5, 0.5, 0.5); Nprop = c(0.8, 1, 1.3);
alphamatrix = matrix(c(1.5, 2, 2.5, 1.8, 2, 2.2, 1.5, 2, 2.5, 1.8, 2, 2.2), nrow = 4, ncol = K, byrow = T);
betamatrix = matrix(c(2, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 4), nrow = 4, ncol = K, byrow = T);
pkw = array(0, dim = c(4, 20, rep));
pw = array(0, dim = c(4, 20, rep));
powerkw = matrix(0, nrow = 4, ncol = 20);
powerw = matrix(0, nrow = 4, ncol = 20);
w = pw;

for(ii in 1:20){
   Nbase = ii*100;
   for(jj in 1:4){
      alpha = alphamatrix[jj,];
	beta = betamatrix[jj, ];
   for(kk in 1:rep){
	N = round(Nbase*Nprop);
	###########Generate Data ###################
	Q = rbinom(sum(N), 1, mean(theta));
	X1 = rbeta(N[1], alpha[1], beta[1])
	X1 = Q[1:N[1]]*X1;
	X2 = rbeta(N[2], alpha[2], beta[2])
	X2 = Q[N[1] + 1:N[2]]*X2;
	X3 = rbeta(N[3], alpha[3], beta[3])
	X3 = Q[N[1] + N[2] +1:N[3]]*X3;

	###########Kruskal Wallis Test ############
	data = list(X1, X2, X3);
	pkw[jj, ii, kk] = kruskal.test(data)$p.value;
	
	###########Our Test ###################
	n = c(sum(Q[1:N[1]]), sum(Q[N[1] + 1:N[2]]), sum(Q[N[1] + N[2] +1:N[3]]))
	prop = n/N; pmax = max(prop);
	Ntrun = round(pmax*N);
	X1trun = c(X1[Q[1:N[1]] == 1], rep(0, Ntrun[1] - n[1]));
	X2trun = c(X2[Q[N[1] + 1:N[2]] == 1], rep(0, Ntrun[2]- n[2]));
	X3trun = c(X3[Q[N[1] + N[2] +1:N[3]] == 1], rep(0, Ntrun[3]- n[3]));
	rankdata = sum(Ntrun) + 1 - rank(c(X1trun, X2trun, X3trun));
	r = c(sum(rankdata[1:Ntrun[1]]), sum(rankdata[Ntrun[1]+1:Ntrun[2]]), sum(rankdata[sum(Ntrun[1:2])+1:Ntrun[3]]) ); 
	s = r - Ntrun*(sum(Ntrun) + 1)/2;
	u = c(N[2]*s[1] - N[1]*s[2], N[3]*sum(s[1:2]) - s[3]*sum(N[1:2]))/Nbase^2;

	thetam = mean(prop);
	simun = matrix(0, nrow = 5000, ncol = K); simup = simun;
	for(ss in 1:K){
		simun[,ss] = rbinom(5000, N[ss], thetam);		
		simup[,ss] = simun[,ss]/N[ss];
	}
	simupmax = apply(simup, 1, max);
	varsimu = numeric(K - 1);
	varsimu[1] = Nprop[2]^2*mean(simupmax^2*(simup[,1] - simup[,2])^2)*N[1]^2;
	for(ss in 2:(K-1)){
		varsimu[ss] = Nprop[ss+1]^2*mean(simupmax^2*(apply(simun[,1:ss], 1, sum) - simup[,ss+1]*sum(N[1:ss]))^2);
	}
	varsimu = varsimu*(sum(Nprop))^2/4;

	varu2 = c(Nprop[1]*Nprop[2], Nprop[3]*sum(Nprop))*(Nprop[1] + Nprop[2])*sum(Nprop)*thetam^2*(sum(N)*thetam + 1)/12;
	varu = varsimu + varu2;
	w[jj, ii, kk] = sum(u^2/varu);
	}
	pw = pchisq(w, 2, lower.tail = F);
	powerkw[jj, ii] = mean(pkw[jj, ii, ] < 0.005);
	powerw[jj, ii] = mean(pw[jj, ii, ] < 0.005);
	}
	print(ii)
}

pdf("C:/Users/wanjiew/Dropbox/Penn/exp3.pdf",width=7,height=7)
par(mfrow = c(2, 2))
N = (1:20)*100;
for(jj in 1:4){
	plot(N, powerkw[jj,], type = "l", lwd = 2, lty = 2, ylim = c(0, 1), ylab = "Power")
	lines(N, powerw[jj,], lwd = 2)
}
dev.off()
save(pw, pkw, powerkw, powerw, alphamatrix,N, Nprop, betamatrix, theta, K, rep, file = "ANOVAexp3.RData")

