#setwd("D:/dropbox/Dropbox/Penn/NonparaTest")
setwd("C:/Users/wanjiew/Dropbox/Penn/NonparaTest") # Set the working directory
source('Wilcoxon.zeros.R') # Load the 
require(xlsx)

# read in data set
disease <- read.delim("G_Remove_unclassfied_Renormalized_Merge_Rel_MetaPhlAn_Result_Disease.xls", stringsAsFactors=FALSE)
normal <- read.delim("G_Remove_unclassfied_Renormalized_Merge_Rel_MetaPhlAn_Result_Normal.xls", stringsAsFactors=FALSE)
rownames(disease) <- disease[,"X"]
rownames(normal) <- normal[,"X"]

# select observations with the same name
intersection <- intersect(normal[,"X"], disease[,"X"])
disease <- disease[intersection,]
normal <- normal[intersection,]

# select the disease data at time point 01
disease <- disease[, grep(".01", colnames(disease), value = T,fixed = T)]
# get rid of the "X" column
normal[,"X"] = NULL
# Normalize the genera again
disease= t(t(disease)/colSums(disease))*100;
normal= t(t(normal)/colSums(normal))*100;
ddata <- as.matrix(disease)
ndata <- as.matrix(normal)

# remove data containing only zeros
ddata <- ddata[(rowSums(disease) != 0) & (rowSums(normal) != 0),]
ndata <- ndata[(rowSums(disease) != 0 & rowSums(normal) != 0),]

num <- dim(ddata)[1] #number of observations
pvalues <- matrix(NA, nrow = num, ncol = 4)
colnames(pvalues) <- c("newStat_perm", "newStat_chisq", "Wilcoxon", "twopart")  
rownames(pvalues) <- rownames(ddata)


#G1 is disease while G2 is normal
perc1 = perc2 = numeric(num);
for (i in (1:num)){
  G1 <- ddata[i,]
  G2 <- ndata[i,]
  perc1[i] <- mean(G1==0); n1 = length(G1)
  perc2[i] <- mean(G2==0); n2 = length(G2)
  pvalues[i, "newStat_perm"] <- Wilcoxon.zeros(G1, G2, perm = TRUE)$p.value         #pvalue for the new statistic
#  pvalues[i, "newStat_chisq"] <- Wilcoxon.zeros(G1, G2)$p.value       #pvalue for the new statistic
  pvalues[i, "Wilcoxon"] <- wilcox.test(G1, G2, paired = F, exact = FALSE)$p.value #pvalue for the two sample Ttest ("two.sided")
  G1score = G1[G1!=0]; G2score = G2[G2!=0]; 
  stat1 = (perc1[i] - perc2[i])^2/(perc1[i]*(1-perc1[i])/n1+perc2[i]*(1-perc2[i])/n2);
  n1 = length(G1score); n2 = length(G2score); r = rank(c(G1score, G2score), tie ="average");
  stat2 = (sum(r[1:n1]) - n1*(n1+n2+1)/2)/sqrt(n1*n2*(n1+n2+1)/12)
  pvalues[i, "twopart"] <- pchisq(stat1+stat2^2, 2, lower.tail = FALSE) #pvalue for the two sample Ttest ("two.sided")
}
perc1 = perc1[!is.na(rowSums(pvalues))]; perc2 = perc2[!is.na(rowSums(pvalues))];
pvalues = pvalues[!is.na(rowSums(pvalues)),]
View(pvalues)

# filename <- file.path(getwd(), paste0("genus__disease_different_time_pvalues.xlsx"))
# write.xlsx(pvalues,filename)
alpha <- 0.05
pwr <- colSums(pvalues < alpha)/num
sigGenius_Perm <- rownames(pvalues[pvalues[,"newStat_perm"] < alpha,])
length(sigGenius_Perm ) #26
# sigGenius_Chisq <- rownames(pvalues[pvalues[,"newStat_chisq"] < alpha,])
# length(sigGenius_Chisq )  #29
sigGenius_Wilcox <- rownames(pvalues[pvalues[,"Wilcoxon"] < alpha,])
length(sigGenius_Wilcox )   #20
sigGenius_twopart <- rownames(pvalues[pvalues[,"twopart"] < alpha,])
length(sigGenius_twopart )   #30

dif = c(setdiff(sigGenius_Chisq, sigGenius_Wilcox), setdiff(sigGenius_Wilcox, sigGenius_Chisq));
difvalue = cbind(ndata[dif,], ddata[dif,])
nn = dim(ndata)[2]; nd = dim(ddata)[2]
label = c(rep("Normal", nn), rep("Crohn's Disease", nd))
colnames(difvalue) <- label;

dif2 = c(setdiff(sigGenius_Perm, sigGenius_twopart), setdiff(sigGenius_twopart, sigGenius_Perm));
difvalue2 = cbind(ndata[dif2,], ddata[dif2,])
colnames(difvalue2) <- label;

# require(reshape2)
# dif.m <- melt(difvalue, id.var = "label")
# require(ggplot2)
# ggplot(data = dif.m, aes(x=Var1, y=value)) + geom_boxplot(aes(fill=Var2), xlab = "", ylab = "")

par(mfrow = c(2,3), mai = c(.7, 1,.7,.2))
for(i in 1:5){
  main1 = paste(strsplit(dif[i], "_")[[1]][3], ", ", sep = "");
  main2 = paste("=", substr(as.character(round(pvalues[dif[i], "newStat_chisq"], 3)), 2, 5), ", ", sep = "");
  main3 = paste("=", substr(as.character(round(pvalues[dif[i], "Wilcoxon"], 3)), 2, 5), sep = "");
  x1 = difvalue[i, 1:26]; x2 = difvalue[i, 27:111];
  perc1 = mean(x1 == 0); perc2 = mean(x2 == 0);
  x1 = x1[x1 != 0]; x2 = x2[x2 != 0]; 
  label = c(rep("Normal", length(x1)), rep("Crohn", length(x2)))
  if(i < 5) {boxplot(c(x1, x2)~label, cex.axis = 2); ymax = max(x1, x2);}
  else {boxplot(c(x1, x2)~label, ylim = c(0, 8.5), cex.axis = 2); ymax = 8.5;}
  title(main = bquote(.(main1) ~ p[s] ~ .(main2) ~ p[S] ~ .(main3)), cex.main=1.8);
  h = ymax/30; perc = max(perc1, perc2)/2;
  rect(1.1, ymax - 3.5*h, 1.1+perc1/2, ymax  - 2*h, col = 2)
  rect(1.1, ymax - 5*h, 1.1+perc2/2, ymax  - 3.5*h, col = 3)
  text(1.1+perc, ymax - 1.5*h, "Percentage of Zeroes:", pos = 3, cex = 1.3)
  text(c(1.1+perc, 1.1+perc), c(ymax - 2.3*h, ymax - 5*h),
       c(paste("Normal (", round(perc1*100), "%)", sep = ""), paste("Crohn (", round(perc2*100), "%)", sep = "")), pos = 4, cex = 2)
  if(i == 1 | i == 4 |i==7){
    title(ylab = "Relative Abundance", cex.lab = 2)
  }
}


par(mfrow = c(3,4), mai = c(.7, 1,.7,.2))
for(i in 1:12){
main1 = paste(strsplit(dif2[i], "_")[[1]][3], ", ", sep = "");
main2 = paste("=", round(pvalues[dif2[i], "newStat_chisq"], 3), ",", sep = "");
main3 = paste("=", round(pvalues[dif2[i], "twopart"], 3), sep = "");
x1 = difvalue2[i, 1:26]; x2 = difvalue2[i, 27:111];
perc1 = mean(x1 == 0); perc2 = mean(x2 == 0);
x1 = x1[x1 != 0]; x2 = x2[x2 != 0]; 
label = c(rep("Normal", length(x1)), rep("Crohn", length(x2)))
boxplot(c(x1, x2)~label, cex.lab = 2); ymax = max(x1, x2);
title(main = bquote(.(main1) ~ p[s] ~ .(main2) ~ p[L] ~ .(main3)), cex.main = 1.2);
h = ymax/30; perc = max(perc1, perc2)/2;
if(i==1){
rect(1.1, ymax - 7*h, 1.1+perc1/2, ymax  - 5.5*h, col = 2)
rect(1.1, ymax - 8.5*h, 1.1+perc2/2, ymax  - 7*h, col = 3)
text(1.1+perc, ymax - 5*h, "Percentage of Zeroes:", pos = 3, cex = 1.3)
text(c(1.1+perc, 1.1+perc), c(ymax - 5.8*h, ymax - 8.1*h),
     c(paste("Normal(", round(perc1*100), "%)", sep = ""), paste("Crohn (", round(perc2*100), "%)", sep = "")), pos = 4, cex = 1.2)
}
else{
rect(1.1, ymax - 3.5*h, 1.1+perc1/2, ymax  - 2*h, col = 2)
rect(1.1, ymax - 5*h, 1.1+perc2/2, ymax  - 3.5*h, col = 3)
text(1.1+perc, ymax - 2.5*h, "Percentage of Zeroes:", pos = 3, cex = 1.3)
text(c(1.1+perc, 1.1+perc), c(ymax - 2.3*h, ymax - 4.6*h),
     c(paste("Normal(", round(perc1*100), "%)", sep = ""), paste("Crohn (", round(perc2*100), "%)", sep = "")), pos = 4, cex = 1.2)
}
if(i == 1 | i == 4 |i==7){
  title(ylab = "Relative Abundance", cex.lab = 2)
}
}

# FDR:
# alpha <- 0.1
# pvalues.fdr = pvalues;
# for(i in 1:3){
# 	pvalues.fdr[,i] = num*pvalues[,i]/rank(pvalues[,i], ties.method = "first");
# }
# pwr.fdr <- colSums(pvalues.fdr < alpha)/num
# 
# sigGenius_Perm <- rownames(pvalues.fdr[pvalues.fdr[,"newStat_perm"] < alpha,])
# length(sigGenius_Perm ) #21
# sigGenius_Chisq <- rownames(pvalues.fdr[pvalues.fdr[,"newStat_chisq"] < alpha,])
# length(sigGenius_Chisq )  #18
# sigGenius_Wilcox <- rownames(pvalues.fdr[pvalues.fdr[,"Wilcoxon"] < alpha,])
# length(sigGenius_Wilcox )   #19
# 
# kk = (1:num)/num
# # Draw qq-plots
# par(mfrow = c(1,3))
# qqplot(kk, pvalues[,"newStat_perm"], xlab = "Null", ylab = "TW, perm")
# qqplot(kk, pvalues[,"newStat_chisq"], xlab = "Null", ylab = "TW, theory")
# qqplot(kk, pvalues[,"Wilcoxon"], xlab = "Null", ylab = "Wilcoxon")
# 
# qqplot(-log(kk, base = 10), -log(pvalues[,"newStat_perm"], 10), xlab = "Null", ylab = "TW, perm")
# qqplot(-log(kk, base = 10), -log(pvalues[,"newStat_chisq"], 10), xlab = "Null", ylab = "TW, theory")
# qqplot(-log(kk, base = 10), -log(pvalues[,"Wilcoxon"], 10), xlab = "Null", ylab = "Wilcoxon")
# 
# 
# library(RColorBrewer)
#  require(fields)
# rf <- colorRampPalette(c("darkcyan", "orange"), space = "rgb")
# r <- rf(32)
# data = cbind(ddata, ndata);
# nb = c(-1, seq(min(data[data >0])/2, 100, by = 100/32), 100); 
# data.plot = data;
# data.plot[data == 0] = runif(sum(data == 0), min = -1, max = 0)
# x <- (1:nrow(data))
# y <- (1:ncol(data))
# image(x, y, data.plot, breaks = nb, col = c("indianred1", r), axes = F, xlab = "", ylab = "")
#  mtext(text=rownames(data), side=3, line=0.3, at=x, las=2, cex=0.5)
# yat = seq(1, length(y), by = 3)
# yname = c(rep("Crohn's Disease", 85), rep("Normal", 26));
#  mtext(text=yname[yat], side=2, line=0.3, at=yat, las = 1, cex=0.8)
# image.plot(x, y, data.plot, breaks = nb, col = c("indianred1", r), legend.only = T)
# 
# rcol = c(rep("red", 85), rep("blue", 26))
# par(oma = c(0.2, 4, 2, 7))
# lmat <- rbind(c(1,2,3), c(4,5,0))
#  lhei <- c(3, 0.5)
#  lwid <- c(0.3, 6, 0.8)
# mar = c(1,1)
# heatmap.2(t(data), scale = "none", Rowv=FALSE, dendrogram = "none", breaks = nb, col = c("indianred1", r),trace = "none", RowSideColors = rcol,  labRow = "", key = FALSE, lmat = lmat, lhei = lhei, lwid = lwid, margins = mar)
# par(oma = c(4, 4, 0, 1))
# image.plot(x, y, data.plot, breaks = nb, col = c("indianred1", r), legend.only = T, legend.shrink = 1, legend.width = 2.2)

# save.image(file = "Normal_vs_Disease.Rdata")
