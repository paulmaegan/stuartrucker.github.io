function Inner = DataInner(X, y, Z, w)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%   Program   %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[n1, p] = size(X); n2 = size(Z, 1);

colnormx = 1./sqrt(nansum(X.^2, 1)/n1)'; colnormz = 1./sqrt(nansum(Z.^2, 1)/n2)';
X = normc(X)*sqrt(n1); Z = normc(Z)*sqrt(n2); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Find LASSO estimator of two coefficient vectors %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% When lambda is unknown, use square-root LASSO instead
% lamlasso = sqrt(norminv(1 - .1/p)/n1); 
lamlasso = 0.5*sqrt(2.01*log(p)/n1); 
cvx_begin quiet
    cvx_solver sedumi
    variable hbeta(p, 1)
    minimize( norm(y - X*hbeta)/sqrt(n1) + lamlasso*norm(hbeta, 1))
cvx_end
if isempty(strfind(cvx_status, 'Solved'))
    error('Error: Scaled Lasso for Coef Failed')
end

lamlasso = sqrt(norminv(1 - .1/p)/n2);
cvx_begin quiet
	variable hgamma(p, 1)
    minimize( norm(w - Z*hgamma)/sqrt(n2) + lamlasso*norm(hgamma, 1))
cvx_end
if isempty(strfind(cvx_status, 'Solved'))
    error('Error: Scaled Lasso for Coef Failed')
end


% The original estimator without de-bias
I = (hbeta.*colnormx)'*(hgamma.*colnormz);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% De-bias the estimator for the first regression system%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma1 = X'*X/n1; resol = 1.5; u1 = zeros(p, 1); tryno = 1; lamstop = 0;  cvx_status = 1;
% lambda1 = norminv(1 - (.1/p^2))/sqrt(n1);
lambda1 = sqrt(2.01*log(p)/n1);
while lamstop == 0 && tryno < 10 % This iteration is to find a good tuning parameter
    lastu1 = u1; lastresp = cvx_status;
    cvx_begin quiet
        variable u1(p, 1)
        minimize( u1'*sigma1*u1/4 + u1'*hgamma + lambda1*norm(u1, 1) )
    cvx_end
    if tryno == 1
        if isempty(strfind(cvx_status, 'Solved'))
            incr = 1; lambda1 = lambda1*resol;
        else
            incr = 0; lambda1 = lambda1/resol;
        end
    else
        if incr == 1 
            if isempty(strfind(cvx_status, 'Solved'))
                lambda1 = lambda1*resol;
            else
                lamstop = 1;
            end
        else
            if isempty(strfind(cvx_status, 'Solved'))
                lambda1 = lambda1*resol; u1 = lastu1; lamstop = 1; cvx_status = lastresp;
            else
                lambda1 = lambda1/resol;
            end
        end
    end
    tryno = tryno + 1;   
end
if isempty(strfind(cvx_status, 'Solved'))
    error('Error: De-bias step Failed')
end
mu1 = -1/2*(X*u1)'*(y - X*hbeta)/n1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% De-bias the estimator for the second regression system%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma2 = Z'*Z/n2; resol = 1.5; u3 = zeros(p, 1); tryno = 1; lamstop = 0; cvx_status = 1;
% lambda2 = norminv(1 - (.1/p^2))/sqrt(n2); 
lambda2 = sqrt(2.01*log(p)/n2); 
while lamstop == 0 && tryno < 10 % This iteration is to find a good tuning parameter
    lastu3 = u3;  lastresp = cvx_status;
    cvx_begin quiet
        variable u3(p, 1)
        minimize( u3'*sigma2*u3/4 + u3'*hbeta + lambda2*norm(u3, 1) )
    cvx_end
    if tryno == 1
        if isempty(strfind(cvx_status, 'Solved'))
            incr = 1; lambda2 = lambda2*resol;
        else
            incr = 0; lambda2 = lambda2/resol;
        end
    else
        if incr == 1 
            if isempty(strfind(cvx_status, 'Solved'))
                lambda2 = lambda2*resol;
            else
                lamstop = 1;
            end
        else
            if isempty(strfind(cvx_status, 'Solved'))
                lambda2 = lambda2*resol; u3 = lastu3; lamstop = 1; cvx_status = lastresp;
            else
                lambda2 = lambda2/resol;
            end
        end
    end
    tryno = tryno + 1;
end
if isempty(strfind(cvx_status, 'Solved'))
    error('Error: De-bias step Failed')
end
mu3 = -1/2*(Z*u3)'*(w - Z*hgamma)/n2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% De-biased estimators %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Inner = I + mu1 + mu3;

end