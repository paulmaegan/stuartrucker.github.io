#!/bin/bash
#$ -l m_mem_free=125G
#$ -j y          

matlab -nodisplay -nodesktop -nosplash < yeastred.m