run /home/stat/wanjiew/cvx/cvx_startup.m
