function FDE = DataNorm(X, y)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%   Program   %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% No Data-splitting
[n1, p] = size(X); 

colnormx = 1./sqrt(nansum(X.^2, 1)/n1)';
X = normc(X)*sqrt(n1); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Find LASSO estimator of two coefficient vectors %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% When lambda is unknown, use square-root LASSO instead
% lamlasso = sqrt(norminv(1 - .1/p)/n1); 
lamlasso = 0.5*sqrt(2.01*log(p)/n1); 
cvx_begin quiet
    cvx_solver sedumi
    variable hbeta(p, 1)
    minimize( norm(y - X*hbeta)/sqrt(n1) + lamlasso*norm(hbeta, 1))
cvx_end
if isempty(strfind(cvx_status, 'Solved'))
    error('Error: Scaled Lasso for Coef Failed')
end

% The original estimator without de-bias
Qbeta = norm(hbeta.*colnormx)^2; 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% De-bias the estimator for the  regression system%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma1 = X'*X/n1; resol = 1.5; 
tryno = 1; u2 = zeros(p, 1); lamstop = 0; cvx_status = 1;
%lambda1 = norminv(1 - (.1/p^2))/sqrt(n1);
lambda1 = sqrt(2.01*log(p)/n1);
while lamstop == 0 && tryno < 10 % This iteration is to find a good tuning parameter
    lastu2 = u2; lastresp = cvx_status;
    cvx_begin quiet
        variable u2(p, 1)
        minimize( u2'*sigma1*u2/4 + u2'*hbeta + lambda1*norm(u2, 1) )
    cvx_end
    if tryno == 1
        if isempty(strfind(cvx_status, 'Solved'))
            incr = 1; lambda1 = lambda1*resol;
        else
            incr = 0; lambda1 = lambda1/resol;
        end
    else
        if incr == 1 
            if isempty(strfind(cvx_status, 'Solved'))
                lambda1 = lambda1*resol;
            else
                lamstop = 1;
            end
        else
            if isempty(strfind(cvx_status, 'Solved'))
                lambda1 = lambda1*resol; u2 = lastu2; lamstop = 1; cvx_status = lastresp;
            else
                lambda1 = lambda1/resol;
            end
        end
    end
    tryno = tryno + 1;
end
if isempty(strfind(cvx_status, 'Solved'))
    error('Error: De-bias step Failed')
end
mu2 = -1/2*(X*u2)'*(y - X*hbeta)/n1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% De-biased estimators %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FDE = max(Qbeta + 2*mu2, 0); 

end