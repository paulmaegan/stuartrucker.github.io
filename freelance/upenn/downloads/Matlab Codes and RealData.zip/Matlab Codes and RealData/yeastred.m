%% Read data from files
datapath = '/home/stat/wanjiew/Documents/MATLAB/RealData';
addpath(datapath);
 
% Read the genotypes
geno = importdata('TransData.txt');
geno = geno.data;
ind = dlmread('ReduceInd.txt');
reduce_geno = geno(:, ind);
geno = reduce_geno; 

% Read the phenotypes
resp = readtable('BYxRM_PhenoData.txt', 'ReadRowNames', 1, 'Delimiter', '\t');
resp2 = zeros(size(resp));
resp = table2array(resp);
for i = 1:46
resp2(:,i) = str2double(resp(:,i));
end
resp = resp2; clear resp2;
 
%% Check the number of missing values for each phenotype
% Note: No missing values for genotype data
checknan = zeros(46, 1);
for i = 1:46
checknan(i) = sum(isnan(resp(:,i)));
end
checknan
 
%% Choose phenotypes: Calcium Chloride (Calcium), Diamide, Hydrogen Peroxide (Hydrogen), Paraquat, Raffinose, 6 Azauracil (Azauracil), YNB, and YPD
ind = [3, 9, 14, 27, 28, 37, 39, 42];
resp = resp(:,ind);
checknan(ind)
 
%% Calculate the correlations
K = length(ind);
Ninner = nchoosek(K, 2);
DisInner = struct('Value', zeros(K, K), 'lower', zeros(K, K), 'upper', zeros(K, K), 'Ratio', zeros(K, K));
 
for kk = 1:(K-1)
    tic
    ind1 = find(~isnan(resp(:,kk))); 
    XX = geno(ind1,:); XX = XX - repmat(mean(XX), length(ind1), 1); XX = normc(XX)*sqrt(length(ind1));
    yy = resp(ind1, kk); yy = (yy - mean(yy))/std(yy);
    for ll = (kk+1):K
        %input non-missing observations
        ind2 = find(~isnan(resp(:,ll)));
        ZZ = geno(ind2,:); ZZ = ZZ - repmat(mean(ZZ), length(ind2), 1); ZZ = normc(ZZ)*sqrt(length(ind2));  
        ww = resp(ind2, ll); ww = (ww - mean(ww))/std(ww);
        DisInner.Value(kk, ll) = DataInner(XX, yy, ZZ, ww);
    end
    DisInner.Value(kk, kk) = DataNorm(XX, yy);
    DisInner.Value(kk, kk)
    toc
end
for kk = 1:(K-1)
    for ll = (kk+1):K
    DisInner.Ratio(kk, ll) = DisInner.Value(kk, ll)/sqrt(DisInner.Value(kk, kk)*DisInner.Value(ll, ll));
    end
end
clear Chrome kk ll geno checknan resp; 
save('data.mat')